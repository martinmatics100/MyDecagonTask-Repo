﻿namespace BANK_CONSOLE_APP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var registration = new Registration();
            registration.RegisterFunction();
        }
    }
}