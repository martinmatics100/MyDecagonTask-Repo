﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANK_CONSOLE_APP
{
    internal class AccountBalance
    {
        public int balance;
        public AccountBalance()
        {
        }

        public int balanceFunction()
        {
            balance = 0;
            return balance; 
        }
    }
}
