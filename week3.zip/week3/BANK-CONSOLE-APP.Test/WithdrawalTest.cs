﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BANK_CONSOLE_APP.Test
{
    public class WithdrawalTest
    {
        [Test]
        public void TestWithdrawalWithSufficientBalance()
        {
            // Arrange: Set up the required user input
            var userInput = new Queue<string>(new[] { "2000", "1000", "1" });

            // Create a StringWriter to capture console output
            var output = new StringWriter();
            Console.SetOut(output);

            // Act: Call the withdrawFunction method
            using (var input = new StringReader(string.Join(Environment.NewLine, userInput)))
            {
                Console.SetIn(input);

                var withdrawal = new Withdrawal();
                withdrawal.withdrawFunction();

                // Assert: Check the console output for success message
                string consoleOutput = output.ToString();
                Assert.IsTrue(consoleOutput.Contains("Your new balance is: 1000"), "Withdrawal should succeed.");
            }
        }



        //[Test]
        //public void TestWithdrawalWithSufficientBalance()
        //{
        //    //Arrange
        //    Customer customer = new Customer("Martin", "Nwatu", "martin@gmail.com", "P@ssword", "1234567890", "Savings", 5000);
        //    //{
        //    //    FirstName = "Martin",
        //    //    LastName = "Nwatu",
        //    //    Email = "martin@gmail.com",
        //    //    Password = "P@ssword",
        //    //    AccountNumber = "1234567890",
        //    //    AccountType = "Savings",
        //    //    Balance = 5000
        //    //};
        //    // Mock user input
        //    var userInput = new Queue<string>(new[] { "123456", "1000", "1" });

        //    // Create a StringWriter to capture console output
        //    var output = new StringWriter();
        //    Console.SetOut(output);

        //    // Act
        //    using (var input = new StringReader(string.Join(Environment.NewLine, userInput)))
        //    {
        //        Console.SetIn(input);

        //        var withdrawal = new Withdrawal();
        //        withdrawal.withdrawFunction();

        //        // Assert
        //        string consoleOutput = output.ToString();
        //        Assert.IsTrue(consoleOutput.Contains("Your new balance is: 1000"), "Withdrawal should succeed.");
        //    }
        //}
    }
}
