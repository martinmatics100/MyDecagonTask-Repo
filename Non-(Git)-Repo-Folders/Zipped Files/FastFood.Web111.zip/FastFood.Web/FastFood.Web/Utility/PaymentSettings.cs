﻿namespace FastFood.Web.Utility
{
    public class PaymentSettings
    {
        public string SecretKey { get; set; }
        public string PublishableKey { get; set; }
    }
}
