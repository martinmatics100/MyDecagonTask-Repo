﻿namespace FastFood.Web.ViewModels
{
    public class CategoryViewModel
    {
        
        public int Id { get; set; }
      
        public string Title { get; set; }
        
    }
}
