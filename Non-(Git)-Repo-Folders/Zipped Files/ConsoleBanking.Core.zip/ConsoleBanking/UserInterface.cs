﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleBanking.Core.Interfaces;
using ConsoleBanking.Core.Implementation;

namespace ConsoleBanking
{
    public class UserInterface
    {
        private readonly ICustomerService _customerService;
        public UserInterface(ICustomerService customerService) 
        { 
            _customerService = customerService;
        }
        public void Run()
        {
            Console.WriteLine("---WELCOME TO SEAPACK BANK---");
            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------");
            Console.WriteLine("|SELECT AN OPTION BELOW TO GET STARTED OR CONTINUE       |");
            Console.WriteLine("--------------------------------------------------------");
            Console.Write("Register: Press 1 to Register: ");
            Console.WriteLine();
            

            Console.WriteLine();
            Console.WriteLine("Enter your choice");
            var choice = Console.ReadLine();

            if (choice == "1")
            {
                _customerService.Register();
            }

        }
    }
}
