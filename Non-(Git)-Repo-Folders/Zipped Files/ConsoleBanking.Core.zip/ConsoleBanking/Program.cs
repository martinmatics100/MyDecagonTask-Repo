﻿using Microsoft.Extensions.DependencyInjection;
using ConsoleBanking.Core.Implementation;
using ConsoleBanking.Data;
using ConsoleBanking.Core.Interfaces;
using ConsoleBanking;

var services = new ServiceCollection();
services.AddScoped<ICustomerService, CustomerService>();
services.AddScoped<ICreateAccount, CreateAccount>();
services.AddScoped<IValidateService, ValidateService>();
services.AddScoped<IAccountService, AccountService>();
services.AddScoped<IBankMenu, BankMenu>();
services.AddSingleton<UserInterface>();

var serviceProvider = services.BuildServiceProvider();
var userInterface = serviceProvider.GetRequiredService<UserInterface>();


userInterface.Run();