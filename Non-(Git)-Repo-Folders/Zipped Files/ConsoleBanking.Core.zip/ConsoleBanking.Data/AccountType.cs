﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBanking.Data
{
    public enum AccountType
    {
        Current = 1,
        Savings = 2
    }
}
