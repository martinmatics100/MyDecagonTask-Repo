﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
//using ConsoleBanking.Core.Interfaces;
//using ConsoleBanking.Core.Implementation;
using System.ComponentModel.DataAnnotations;

namespace ConsoleBanking.Data.Dtos
{
    public class RegisterDTO
    {
        [Required] public string firstName { get; set; }
        [Required] public string lastName { get; set; }
        [Required] public string email { get; set; }
        [Required] public string password { get; set; }

        
       


    }

}
