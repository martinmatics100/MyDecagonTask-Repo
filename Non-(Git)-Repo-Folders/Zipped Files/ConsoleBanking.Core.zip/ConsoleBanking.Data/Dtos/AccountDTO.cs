﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBanking.Data.Dtos
{
    public class AccountDTO
    {
    }
}
