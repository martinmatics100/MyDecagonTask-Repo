﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBanking.Data
{
    public class Transaction
    {
        public decimal Amount;
        public string Description;
        public Transaction(decimal Amount, string Description) 
        { 
            this.Amount = Amount;
            this.Description = Description;
        }
    }
}
