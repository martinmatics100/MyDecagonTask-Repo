﻿namespace ConsoleBanking.Data
{
    public class Customer
    {
        public string FirstName;
        public string LastName;
        public string Email;
        public string Password;
        public string AccountNumber;
       

        public Customer(string FirstName, string LastName, string Email, string Password, string AccountNumber)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.Password = Password;
            this.AccountNumber = AccountNumber;
            
        }
    }
}
