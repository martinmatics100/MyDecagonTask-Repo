﻿namespace ConsoleBanking.Core
{
    public class Class1
    {

    }
}