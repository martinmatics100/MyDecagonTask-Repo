﻿namespace ConsoleBanking.Core.Interfaces
{
    public interface IBankMenu
    {
        void BankMenuFunc();
    }
}