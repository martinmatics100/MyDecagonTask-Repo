﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleBanking.Data;

namespace ConsoleBanking.Core.Interfaces
{
    public interface ICustomerService
    {
        List<Customer> customers { get; }
        List<Account> accounts { get; }
        void Register();
        void LogIn();
        void AnotherAccount();
    }
}
