﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBanking.Core.Interfaces
{
    public interface IValidateService
    {
        string ValidateEmail();
        string ValidateFirstName();
        string ValidateLastName();
        string ValidatePassword();
        bool IsValidEmail(string email);
        bool IsAlphanumeric(string Password);

    }
}
