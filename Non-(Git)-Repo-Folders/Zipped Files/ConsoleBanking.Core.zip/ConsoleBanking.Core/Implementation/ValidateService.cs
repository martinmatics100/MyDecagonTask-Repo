﻿using ConsoleBanking.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleBanking.Core.Implementation
{
    public class ValidateService : IValidateService
    {
        public string ValidateEmail()
        {
            while (true)
            {
                Console.Write("Enter Email Address: ");
                string email = Console.ReadLine();

                if (!IsValidEmail(email))
                {
                    Console.WriteLine("Invalid Email, please enetr a valid email address");
                    continue;
                }
                return email;
            }
        }

        public string ValidateFirstName()
        {
            while (true)
            {
                Console.Write("FirstName (Kindly begin name with capital letter): ");
                string FirstName = Console.ReadLine();

                if (!Char.IsUpper(FirstName[0]))
                {
                    Console.WriteLine("Your name did not start with upper case, try again");
                    continue;
                }

                if (Char.IsDigit(FirstName[0]))
                {
                    Console.WriteLine("Your name must not start with a digit");
                    continue;
                }
                return FirstName;
            }
        }

        public string ValidateLastName()
        {
            while (true)
            {
                Console.Write("Enter LastName (Kindly begin name with uppercase): ");
                string LastName = Console.ReadLine();

                if (!Char.IsUpper(LastName[0]))
                {
                    Console.WriteLine("Your name did not start with upper case, try again");
                    continue;
                }

                if (Char.IsDigit(LastName[0]))
                {
                    Console.WriteLine("Your name must not start with a number");
                    continue;
                }

                return LastName;
            }
        }

        string IValidateService.ValidatePassword()
        {
            while (true)
            {
                Console.WriteLine("Enter Password (Your password must be a minimum of 6 characters and alphanumeric): ");
                string Password = Console.ReadLine();

                if (Password.Length < 6)
                {
                    Console.WriteLine("Your password must not be less than 6 characters");
                    continue;
                }
                if (!IsAlphanumeric(Password))
                {
                    Console.WriteLine("The password must be alphanumeric");
                    continue;
                }
                return Password;
            }
        }

        public bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        public bool IsAlphanumeric(string Password)
        {
            return Regex.IsMatch(Password, @"^(?=.*[a-zA-Z0-9])(?=.*[^a-zA-Z0-9]).{8,}$");
        }
    }
}
