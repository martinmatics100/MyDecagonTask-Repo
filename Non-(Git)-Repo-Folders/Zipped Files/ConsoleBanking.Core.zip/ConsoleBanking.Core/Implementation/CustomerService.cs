﻿using ConsoleBanking.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleBanking.Data;
using System.Security.Principal;
using System.Security.Cryptography.X509Certificates;
using ConsoleBanking;
using System.Xml.Linq;

namespace ConsoleBanking.Core.Implementation
{
    public class CustomerService : ICustomerService
    {
        public static List<Customer> customers = new List<Customer>();
        public static List<Account> accounts = new List<Account>();
        private readonly IValidateService _validateService;
        private readonly ICreateAccount _createAccount;
        private readonly IBankMenu _bankMenu;
        public string FirstName;
        public string LastName;
        public string Email;
        public string Password;
        public string AccountNumber;
        public string AccountType;
        public decimal AccountBalance;

        List<Customer> ICustomerService.customers => throw new NotImplementedException();

        List<Account> ICustomerService.accounts => throw new NotImplementedException();

        public CustomerService(IValidateService validateService, ICreateAccount createAccount, IBankMenu bankMenu)
        { 
            _validateService = validateService;
            _createAccount = createAccount;
           
            _bankMenu = bankMenu;
        }
        
      

        public void Register()
        {
            bool exit = false;
             while (!exit)
            {
                Console.Clear();

                Console.WriteLine("Enter Your Details to Below to Register:");

                FirstName = _validateService.ValidateFirstName();
                LastName = _validateService.ValidateLastName();
                Email = _validateService.ValidateEmail();
                Password = _validateService.ValidatePassword();
                AccountNumber = _createAccount.AccountNo();
                AccountType = _createAccount.TypeAccount();
                AccountBalance = _createAccount.AccountBal();   

                Customer customer = new Customer(FirstName, LastName, Email, Password, AccountNumber);
                customers.Add(customer);
                
                Account account = new Account(AccountNumber, AccountType, AccountBalance);
                accounts.Add(account);

                Console.WriteLine("Customer added successfully");
                Console.WriteLine("Would you want to add another customer? (Y/N)");
                string choice = Console.ReadLine()!;

                if (choice.Equals("N", StringComparison.OrdinalIgnoreCase))
                {
                    exit = true;
                }
                else
                {
                   AnotherAccount();
                }


            }

            Console.WriteLine("THE CUSTOMER DETAILS");
            Console.WriteLine("|--------------------------------------|");

 


            foreach (var customer in customers)
            {
                Console.WriteLine($"FirstName: {customer.FirstName}");
                Console.WriteLine($"LastName: {customer.LastName}");
                Console.WriteLine($"Fullname: {customer.FirstName} {customer.LastName}");
                Console.WriteLine($"Email: {customer.Email}");
                Console.WriteLine($"AccountNumber: {customer.AccountNumber}");
               

            }
            foreach (var item in accounts)
            {
                Console.WriteLine($"AccountType: {item.AccountType}");
                Console.WriteLine($"Balance: {item.AccountBalance}");
            }

            Console.WriteLine("KINDLY LOGIN BELOW");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("Enter 2 to Login");
            string input = Console.ReadLine();
            if (input == "2")
            {
                LogIn();
            }


        }
        public void LogIn()
        {
            Console.Clear();
            Console.Write("Enter Email Adderss: ");
            string LoginEmail = Console.ReadLine();
            foreach (var item in customers)
            {
                if (LoginEmail == item.Email)
                {
                    Console.Write("Enter Password");
                    string LoginPassword = Console.ReadLine();
                    if (LoginPassword == item.Password)
                    {
                        Console.Clear();
                        _bankMenu.BankMenuFunc();
                        
                    }
                    else
                    {
                        LogIn();
                    }
                }
                else
                {
                    LogIn();
                }
            }
        }

        public void AnotherAccount()
        {

            Console.Clear();
            
            string OtherAccountNumber = _createAccount.AccountNo();
            string OtherAccountType = _createAccount.TypeAccount();
            decimal OtherBalance = _createAccount.AccountBal();
            Account account = new Account(OtherAccountNumber, OtherAccountType, OtherBalance);
            accounts.Add(account);
            Customer customer = new Customer(FirstName, LastName, Email, Password, OtherAccountNumber);
            customers.Add(customer);

            Console.WriteLine("Customer added successfully");
            Console.WriteLine("Would you want to add another customer? (Y/N)");
            string choice = Console.ReadLine()!;

            if (choice.Equals("N", StringComparison.OrdinalIgnoreCase))
            {
                foreach (var user in customers)
                {

                    Console.WriteLine($"FirstName: {user.FirstName}");
                    Console.WriteLine($"LastName: {user.LastName}");
                    Console.WriteLine($"Fullname: {user.FirstName} {customer.LastName}");
                    Console.WriteLine($"Email: {user.Email}");
                    Console.WriteLine($"AccountNumber: {user.AccountNumber}");
                    

                }
                foreach (var item in accounts)
                {
                    Console.WriteLine($"AccountType: {item.AccountType}");
                    Console.WriteLine($"Balance: {item.AccountBalance}");
                }

                Console.WriteLine("Enter 1 to login");
                string login = Console.ReadLine()!;
                if (login == "1")
                {
                    LogIn();
                }
            }
            else
            {
                AnotherAccount();
            }

        }

    }
}
