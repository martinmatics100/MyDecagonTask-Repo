﻿using ConsoleBanking.Core.Interfaces;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleBanking.Core.Implementation
{
    public class BankMenu : IBankMenu
    {
        private readonly ICustomerService _customerService;
        private readonly IAccountService _accountService;
        public BankMenu(ICustomerService customerService, IAccountService accountService)
        {
            _customerService = customerService;
            _accountService = accountService;
        }



        public string choice;

        public void BankMenuFunc()
        {

            Console.WriteLine("-----------------------------------------------------");
            Console.WriteLine("WHAT WOULD YOU LIKE TO DO TODAY");
            Console.WriteLine("-----------------------------------------------------");


            Console.WriteLine("1. CREATE ANOTHER ACCOUNT");
            Console.WriteLine();
            Console.WriteLine("2. DEPOSIT");
            Console.WriteLine();
            Console.WriteLine("3. WITHDRAW");
            Console.WriteLine();
            Console.WriteLine("4. TRANSFER");
            Console.WriteLine();
            Console.WriteLine("5. CHECK BALANCE");
            Console.WriteLine();
            Console.WriteLine("6. CHECK ACCOUNT DETAILS");
            Console.WriteLine();
            Console.WriteLine("7. CHECK STATMENT");
            Console.WriteLine();
            Console.WriteLine("8. LOGOUT");
            Console.WriteLine("ENTER ANY OF THE NUMBERS TO SELECT AN OPTION");
            choice = Console.ReadLine();

            if (choice == "1")
            {
                _customerService.AnotherAccount();
            }
            if (choice == "2")
            {
                _accountService.Deposit();
            }
            if (choice == "3")
            {
                //var withdraw = new Withdraw();
                //withdraw.withdrawFunc();
            }
            if (choice == "4")
            {
                //var Transfer = new Transfer();
                //Transfer.TransferFunds();
            }
            if (choice == "5")
            {
                //var checkBalance = new CheckBalance();
                //checkBalance.CheckBalanceFunc();
            }
            if (choice == "6")
            {
                //var accountdetails = new AccountDetails();
                //accountdetails.AccountDetail();
            }
            if (choice == "7")
            {
                //var PrintStatement = new PrintStatementClass();
                //PrintStatement.PrintStatement();
            }
            if (choice == "8")
            {
                //var logout = new Logout();
                //logout.LogoutFunc();
            }
        }
    }
}
