﻿using ConsoleBanking.Core.Interfaces;
using ConsoleBanking.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Transactions;
using ConsoleBanking.Data;

namespace ConsoleBanking.Core.Implementation
{
    public class AccountService : IAccountService 
    {
        public static  List<Transaction> transactions = new List<Transaction>();
        private readonly ICustomerService _customerService;
        private readonly IBankMenu _bankMenu;
        
        public decimal Amount;
        public string Description;

        public AccountService(ICustomerService customerService, IBankMenu bankMenu) 
        { 
            _customerService = customerService;
            _bankMenu = bankMenu;
           
        }    
        public void Deposit()
        {

            Console.Clear();
            Console.WriteLine("DEPOSIT FUNDS");
            Console.WriteLine();
            Console.Write("Enter amount to deposit: ");
            Amount = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Account Number");
            string AccNo = Console.ReadLine();

            Console.WriteLine("Enter a description");
            Description = Console.ReadLine();



            foreach (var item in _customerService.accounts)
            {

                if (AccNo == item.AccountNumber && item.AccountBalance != null)
                {
                    item.AccountBalance += Amount;


                    Console.WriteLine($"Your new balance is: {item.AccountBalance}");
                    Console.WriteLine();
                    Transaction transaction = new Transaction(Amount, Description);
                    transactions.Add(transaction);
                    



                    Console.WriteLine("SEE YOUR UPDATES BELOW");
                    

                   // Console.WriteLine($"FirstName: {item.FirstName}");
                    //WriteLine($"LastName: {item.LastName}");
                    //Console.WriteLine($"Fullname: {item.FirstName} {item.LastName}");
                    //Console.WriteLine($"Email: {item.Email}");
                    Console.WriteLine($"AccountNumber: {item.AccountNumber}");
                    Console.WriteLine($"AccountType: {item.AccountType}");
                    Console.WriteLine($"Balance: {item.AccountBalance}");
                    

                }



            }
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("Enter 1 to go back to BankMenu");
            string choice = Console.ReadLine();
            if (choice == "1")
            {
                Console.Clear();
                _bankMenu.BankMenuFunc();
                
            }
        }
    }
}
