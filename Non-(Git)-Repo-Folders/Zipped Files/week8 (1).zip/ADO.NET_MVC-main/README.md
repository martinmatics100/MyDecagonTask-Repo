# ADO.NET_MVC
Used ADO.NET for data access. 
------------------------------
Steps:
--------
1. Open the project in visual studio.
2. Change the connection string to your local connection string.
3. Publish the database by right-clicking on the database and clicking on "publish".
4. ADO was used for all data access operations.
5. Run project.
