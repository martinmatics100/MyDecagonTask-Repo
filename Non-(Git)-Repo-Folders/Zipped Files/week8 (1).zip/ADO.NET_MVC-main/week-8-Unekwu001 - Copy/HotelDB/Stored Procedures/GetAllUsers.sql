﻿ CREATE PROCEDURE GetAllUsers
 AS

 BEGIN

	select * from dbo.users
END
