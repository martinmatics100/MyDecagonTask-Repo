﻿ CREATE PROCEDURE GetAllHotels
 AS

 BEGIN

	select * from dbo.hotels
END