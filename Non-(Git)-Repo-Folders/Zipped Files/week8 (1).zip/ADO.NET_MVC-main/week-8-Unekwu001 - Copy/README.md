Steps to Launch Project
--------------------------
Make sure to publish the database to your prefered server. You can achieve this by right clicking on the database. Click on publish and follow the prompt.

Thank you..
