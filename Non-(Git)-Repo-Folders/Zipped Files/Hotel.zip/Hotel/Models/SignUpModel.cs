﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Hotel.Models
{
	public class SignUpModel
	{
		[Required]
		public Guid Id { get; set; }

		[Required]
		public string? Fullname { get; set; }

		[Required]
		[EmailAddress]
		public string? Email { get; set; }

		[Required]
		[PasswordPropertyText]
		public string? Password { get; set; }

		  
		public DateTime RegDate { get; set; }

		public SignUpModel()
		{
			RegDate = DateTime.Now;
			Id = Guid.NewGuid();
		}
	}
}
