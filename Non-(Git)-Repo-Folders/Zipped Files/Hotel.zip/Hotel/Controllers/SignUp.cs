﻿using Microsoft.AspNetCore.Mvc;
using Hotel.Models;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;

namespace Hotel.Controllers
{
		public class SignUpController : Controller
		{

			public IActionResult Signing_up()
			{
				return View();
			}



			[HttpPost]
			public IActionResult Signing_up(SignUpModel signUpModel)
			{
				var AllUsers = ReadUsersFile("Users.txt");
				if (ModelState.IsValid)
				{
					// Access the form data from the signUpModel object
					Guid id = signUpModel.Id;
					string? fullname = signUpModel.Fullname;
					string? email = signUpModel.Email;
					string? password = signUpModel.Password;
					string? hashedPassword = HashPassword(password);

					var userExist = AllUsers.FirstOrDefault(user => user.Email == email);

					if(userExist is null)
					{
						using (StreamWriter writer = new StreamWriter("Users.txt",true))
						{
					
							writer.WriteLine($"| {id} | {fullname} | {email} | {hashedPassword} |");
					
						}
						// Redirect to a success page or perform any other action
						TempData["Message"] = "Registration successful.";
						return RedirectToAction("LoginPage", "Login");

					}
					else
					{
						TempData["ErrorMessage"] = "User Already Exist.";
						return View(signUpModel);
					}

				
				
				}
				else
				{
				// If the model state is not valid, return the view with validation errors
					TempData["ErrorMessage"] = "A problem occurred. Please check your input.";
					return View(signUpModel);
				}
				
			}






		private string HashPassword(string password)
		{
			using (SHA256 sha256 = SHA256.Create())
			{
				byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
				return Convert.ToBase64String(hashedBytes);
			}
		}


		public static List<SignUpModel> ReadUsersFile(string filePath)
		{
			List<SignUpModel> Users = new List<SignUpModel>();

			using (StreamReader reader = new StreamReader(filePath))
			{
				string line;
				while ((line = reader.ReadLine()) != null)
				{
					if (!string.IsNullOrWhiteSpace(line))
					{
						string[] fields = line.Split('|');

						if (fields.Length >= 4)
						{
							string id = fields[1].Trim();
							string name = fields[2].Trim();
							string email = fields[3].Trim();
							string password = fields[4].Trim();

							SignUpModel  user = new SignUpModel();

							user.Id = Guid.Parse(id);
							user.Fullname = name;
							user.Email = email;
							user.Password = password;	
							Users.Add(user);
						}
					}
				}
			}

			return Users;
		}
	}
	}

