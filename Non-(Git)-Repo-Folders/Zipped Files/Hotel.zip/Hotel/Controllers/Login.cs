﻿using Microsoft.AspNetCore.Mvc;

namespace Hotel.Controllers
{
	public class Login : Controller
	{
		public IActionResult LoginPage() 
		{
			ViewBag.SuccessMessage = TempData["SuccessMessage"]?.ToString();
			return View();
		}
	}
}
