﻿namespace ConsoleBankingApp
{
    internal class Balance
    {
        public int balance;
        public Balance()
        {
        }

        public int balanceFunc()
        {
            balance = 0;
            return balance;
        }
    }
}