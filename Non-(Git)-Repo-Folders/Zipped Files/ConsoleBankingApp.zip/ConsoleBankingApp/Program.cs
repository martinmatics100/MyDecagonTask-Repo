﻿using System;

namespace ConsoleBankingApp
{
    public class Program 
    {
        public static void Main(string[] args)
        {
            var Register = new Index();
            Register.RegIndex();
            
        }
    }
}